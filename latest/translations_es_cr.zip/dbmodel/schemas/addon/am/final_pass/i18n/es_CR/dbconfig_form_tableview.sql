/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = am, public;
UPDATE config_form_tableview AS t SET alias = v.alias FROM (
	VALUES
	('cat_result', 'budget', 'Presupuesto'),
    ('cat_result', 'cur_user', 'Usuario Actual'),
    ('cat_result', 'descript', 'Descr'),
    ('cat_result', 'dnom', 'DNOM'),
    ('cat_result', 'expl_id', 'Id Explotación'),
    ('cat_result', 'features', 'Entidades'),
    ('cat_result', 'iscorporate', 'Corporativo'),
    ('cat_result', 'material_id', 'Id Material'),
    ('cat_result', 'presszone_id', 'Id Zona Presión'),
    ('cat_result', 'report', 'Informe'),
    ('cat_result', 'result_id', 'Id Resultado'),
    ('cat_result', 'result_name', 'Nombre Resultado'),
    ('cat_result', 'result_type', 'Tipo'),
    ('cat_result', 'status', 'Estado'),
    ('cat_result', 'target_year', 'Año Horizonte'),
    ('cat_result', 'tstamp', 'Paso de tiempo')
) AS v(objectname, columnname, alias)
WHERE t.objectname = v.objectname AND t.columnname = v.columnname;