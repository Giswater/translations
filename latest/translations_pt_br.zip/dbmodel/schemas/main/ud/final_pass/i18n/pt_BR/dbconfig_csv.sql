/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'Importar db prices', E'O arquivo CSV deve conter nas mesmas posições as seguintes colunas: id, unit, descript, text, price. \n- A coluna price deve ser numérica com duas casas decimais. \n- Você pode escolher um nome de catálogo para esses preços definindo um rótulo de importação.'),
    (235, 'Importar elementos', E'O arquivo CSV deve conter as seguintes colunas na mesma posição:\nId (arc_id, node_id, connec_id), code, elementcat_id, observ, comment, num_elements, state type (id), workcat_id, verified (choose from edit_typevalue>value_verified).\n- Os campos observ e comment são opcionais\n- ATENÇÃO! O campo Import label deve ser preenchido com o tipo de elemento (node, arc, connec)'),
    (238, 'Importar om visit', E'Para usar este parâmetro/função de importação csv você precisa configurar antes de executar o parâmetro do sistema ''utils_csv2pg_om_visit_parameters''.\nTambém recomendamos ler previamente as anotações dentro da função para que ela funcione o melhor possível com'),
    (384, 'Importar arquivos inp de curvas', E'Função para automatizar a importação de arquivos inp de curvas.\nO arquivo csv deve conter as seguintes colunas na mesma ordem:\ncurve_id, x_value, y_value, curve_type (para projeto WS OU projeto UD curve_type tem valores diferentes. Consulte o manual do usuário)'),
    (385, 'Importar séries temporais inp', 'Função para auxiliar a importação de séries temporais para modelos inp. O arquivo csv deve conter as seguintes colunas nas mesmas posições: timseries, timser_type, times_type, descript, expl_id, date, hour, time, value (preencha date/hour para ABSOLUTE ou time para RELATIVE)'),
    (386, 'Importar arquivos inp de padrões', E'Função para automatizar a importação de arquivos inp de padrões.\nO arquivo csv deve conter as seguintes colunas na mesma ordem:\npattern_id, pattern_type, factor1,.......,factorn.\nPara WS use até factor18, repetindo linhas se desejar.\nPara UD use até factor24. Não é permitido mais de uma linha por padrão'),
    (408, 'Importar nós istram', NULL),
    (409, 'Importar arcos istram', NULL),
    (444, 'Importar cat_feature_arc', E'O arquivo CSV deve conter as seguintes colunas na exata mesma ordem:\nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (445, 'Importar cat_feature_node', E'O arquivo CSV deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, isarcdivide, isprofilesurface, choose_hemisphere, code_autofill, double_geom, num_arcs, graph_delimiter, shortcut_key, link_path, descript, active'),
    (446, 'Importar cat_feature_connec', E'O arquivo CSV deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (447, 'Importar cat_feature_gully', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, code_autofill, double_geom, shortcut_key, link_path, descript, active'),
    (448, 'Importar cat_node', E'O arquivo CSV deve conter as seguintes colunas na mesma ordem exata: \nid, nodetype_id, matcat_id, pnom, dnom, dint, dext, shape, descript, link, brand, model, svg, estimated_depth, cost_unit, cost, active, label, ischange, acoeff'),
    (449, 'Importar cat_connec', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, connectype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, active, label'),
    (450, 'Importar cat_arc', E'O arquivo CSV deve conter as seguintes colunas na mesma ordem exata: \nid, arctype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, z1, z2, width, area, estimated_depth, bulk, cost_unit, cost, m2bottom_cost, m3protec_cost, active, label, shape, acoeff, connect_cost'),
    (451, 'Importar cat_grate', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, matcat_id, length, width, total_area, effective_area, n_barr_l, n_barr_w, n_barr_diag, a_param, b_param, descript, link, brand, model, svg, active, label, gully_type'),
    (469, 'Importar valores scada', 'Importar valores scada para a tabela ext_rtc_scada_x_data conforme o arquivo de exemplo scada_values.csv'),
    (470, 'Importar hydrometer_x_data', E'O arquivo CSV deve conter os seguintes campos:\nhydrometer_id, cat_period_id, sum, value_date (optional), value_type (optional), value_status (optional), value_state (optional)'),
    (471, 'Importar valores de período crm', E'O arquivo CSV deve conter os seguintes campos:\nid, start_date, end_date, period_seconds (optional), code'),
    (527, 'Importar DWF', 'Função para importar valores DWF. O arquivo CSV deve conter as seguintes colunas na mesma ordem exata:   dwfscenario_id, node_id, value, pat1, pat2, pat3, pat4')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;