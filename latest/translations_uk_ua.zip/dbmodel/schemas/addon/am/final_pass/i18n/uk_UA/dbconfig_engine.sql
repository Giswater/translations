/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = am, public;
UPDATE config_engine_def AS t SET label = v.label, descript = v.descript, placeholder = v.placeholder FROM (
	VALUES
	('bratemain0', 'SH', 'Коефіцієнт частоти проривів', 'Темп зростання витоків у трубі', NULL),
    ('compliance', 'SH', 'Регуляторна вага', 'Вага в фінальній матриці для дотримання нормативних вимог', NULL),
    ('compliance_1', 'WM', 'Регуляторний', NULL, NULL),
    ('compliance_2', 'WM', 'Регуляторний', NULL, NULL),
    ('drate', 'SH', 'Ставка дисконту (%)', 'Реальна ставка дисконту ціни. Бере до уваги зростання цін шляхом дисконтування інфляції.', NULL),
    ('expected_year', 'SH', 'Очікувана річна вага', 'Вага в фінальній матриці за рік оновлення', NULL),
    ('flow_1', 'WM', 'Оборотний капітал', NULL, NULL),
    ('flow_2', 'WM', 'Оборотний капітал', NULL, NULL),
    ('longevity_1', 'WM', 'Довговічність', NULL, NULL),
    ('longevity_2', 'WM', 'Довговічність', NULL, NULL),
    ('mleak_1', 'WM', 'Ймовірність відмови', NULL, NULL),
    ('mleak_2', 'WM', 'Ймовірність відмови', NULL, NULL),
    ('nrw_1', 'WM', 'ANC', NULL, NULL),
    ('nrw_2', 'WM', 'ANC', NULL, NULL),
    ('rleak_1', 'WM', 'Фактичні прориви', NULL, NULL),
    ('rleak_2', 'WM', 'Фактичні прориви', NULL, NULL),
    ('strategic', 'SH', 'Стратегічна вага', 'Вага в фінальній матриці за стратегічними факторами', NULL),
    ('strategic_1', 'WM', 'Стратегічний', NULL, NULL),
    ('strategic_2', 'WM', 'Стратегічний', NULL, NULL)
) AS v(parameter, method, label, descript, placeholder)
WHERE t.parameter = v.parameter AND t.method = v.method;