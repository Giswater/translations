/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = cm, public, public;
UPDATE sys_typevalue AS t SET idval = v.idval, descript = v.descript FROM (
	VALUES
	('1', 'campaign_feature_status', 'ЗАПЛАНОВАНО', NULL),
    ('1', 'campaign_status', 'ПЛАНУВАННЯ', NULL),
    ('1', 'campaign_type', 'ПЕРЕГЛЯД', NULL),
    ('1', 'lot_feature_status', 'ЗАПЛАНОВАНО', NULL),
    ('1', 'lot_status', 'ПЛАНУВАННЯ', NULL),
    ('10', 'campaign_status', 'СКАСОВАНО', NULL),
    ('10', 'lot_status', 'СКАСОВАНО', NULL),
    ('2', 'campaign_feature_status', 'НЕ ВІДВІДАНО', NULL),
    ('2', 'campaign_status', 'ЗАПЛАНОВАНО', NULL),
    ('2', 'campaign_type', 'ВІЗИТ', NULL),
    ('2', 'lot_feature_status', 'НЕ ВІДВІДАНО', NULL),
    ('2', 'lot_status', 'ЗАПЛАНОВАНО', NULL),
    ('3', 'campaign_feature_status', 'ВІДВІДАНО', NULL),
    ('3', 'campaign_status', 'ПРИЗНАЧЕНО', NULL),
    ('3', 'campaign_type', 'ІНВЕНТАР', NULL),
    ('3', 'lot_feature_status', 'ВІДВІДАНО', NULL),
    ('3', 'lot_status', 'ПРИЗНАЧЕНО', NULL),
    ('4', 'campaign_feature_status', 'ПОВТОРНИЙ ВІЗИТ', NULL),
    ('4', 'campaign_status', 'В ПРОЦЕСІ', NULL),
    ('4', 'lot_feature_status', 'ПОВТОРНИЙ ВІЗИТ', NULL),
    ('4', 'lot_status', 'В ПРОЦЕСІ', NULL),
    ('5', 'campaign_feature_status', 'ПРИЙНЯТО', NULL),
    ('5', 'campaign_status', 'РЕЗЕРВ', NULL),
    ('5', 'lot_feature_status', 'ПРИЙНЯТО', NULL),
    ('5', 'lot_status', 'РЕЗЕРВ', NULL),
    ('6', 'campaign_feature_status', 'СКАСОВАНО', NULL),
    ('6', 'campaign_status', 'ВИКОНАНО', NULL),
    ('6', 'lot_feature_status', 'СКАСОВАНО', NULL),
    ('6', 'lot_status', 'ВИКОНАНО', NULL),
    ('7', 'campaign_status', 'ВІДХИЛЕНО', NULL),
    ('7', 'lot_status', 'ВІДХИЛЕНО', NULL),
    ('8', 'campaign_status', 'ГОТОВИЙ-ДО-ПРИЙНЯТТЯ', NULL),
    ('8', 'lot_status', 'ГОТОВИЙ-ДО-ПРИЙНЯТТЯ', NULL),
    ('9', 'campaign_status', 'ПРИЙНЯТО', NULL),
    ('9', 'lot_status', 'ПРИЙНЯТО', NULL),
    ('lyt_buttons', 'layout_name_typevalue', 'lyt_кнопки', NULL)
) AS v(id, typevalue, idval, descript)
WHERE t.id = v.id AND t.typevalue = v.typevalue;