/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = cm, public, public;
UPDATE sys_fprocess AS t SET except_msg = v.except_msg, info_msg = v.info_msg, fprocess_name = v.fprocess_name FROM (
	VALUES
	(100, 'нульове значення в стовпці %check_column% таблиці %table_name%.', '%check_column% у %table_name% має правильні значення.', 'Перевірка узгодженості NULL-значень'),
    (200, 'Є деякі користувачі без призначеної команди.', 'Усі користувачі мають призначену команду.', 'Перевірте консистентність користувачів'),
    (201, 'команди без призначених користувачів.', 'Усі команди мають призначених користувачів.', 'Перевірити консистентність команд'),
    (202, 'Є кілька вузлів-сиріт.', 'Вузлів-сиріт немає.', 'Перевірте вузли-сироти'),
    (203, 'вузли, дубльовані зі станом 1.', 'Немає вузлів, дубльованих зі станом 1', 'Перевірте дубльовані вузли')
) AS v(fid, except_msg, info_msg, fprocess_name)
WHERE t.fid = v.fid;