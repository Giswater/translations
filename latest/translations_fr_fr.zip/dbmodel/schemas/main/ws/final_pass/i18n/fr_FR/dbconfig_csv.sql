/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'Importer les prix en base', E'Le fichier csv doit contenir les colonnes suivantes, dans cet ordre : id, unit, descript, text, price.\n- La colonne price doit être numérique avec deux décimales.\n- Vous pouvez choisir un nom de catalogue pour ces prix en renseignant un libellé d''import.'),
    (235, 'Importer des éléments', E'Le fichier csv doit contenir les colonnes suivantes, dans cet ordre :\nId (arc_id, node_id, connec_id), code, elementcat_id, observ, comment, num_elements, state type (id), workcat_id, verified (choisir depuis edit_typevalue>value_verified).\n- Les champs observations et comments sont optionnels\n- ATTENTION ! Le libellé d''import doit être renseigné avec le type d''élément (node, arc, connec)'),
    (238, 'Importer om visit', E'Pour utiliser cette fonction d''import CSV, vous devez préalablement configurer le paramètre système ''utils_csv2pg_om_visit_parameters''.\nNous vous recommandons également de lire avant les annotations à l''intérieur de la fonction pour travailler aussi bien que possible avec elle'),
    (384, 'Importer courbes inp', E'Fonction pour automatiser l''import des fichiers de courbes inp.\nLe fichier csv doit contenir les colonnes suivantes, dans cet ordre :\ncurve_id, x_value, y_value, curve_type (pour un projet WS ou UD, curve_type a des valeurs différentes. Voir le manuel utilisateur)'),
    (386, 'Importer patterns inp', E'Fonction pour automatiser l''import des fichiers de patterns inp.\nLe fichier csv doit contenir les colonnes suivantes, dans cet ordre :\npattern_id, pattern_type, factor1,.......,factorn.\nPour WS, utiliser jusqu''à factor18, en répétant les lignes si nécessaire.\nPour UD, utiliser jusqu''à factor24. Plus d''une ligne par pattern n''est pas autorisée'),
    (444, 'Importer cat_feature_arc', E'Le fichier CSV doit contenir les colonnes suivantes dans exactement le même ordre : \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (445, 'Importer cat_feature_node', E'Le fichier CSV doit contenir les colonnes suivantes dans exactement le même ordre : \nid, system_id, epa_default, isarcdivide, isprofilesurface, choose_hemisphere, code_autofill, double_geom, num_arcs, graph_delimiter, shortcut_key, link_path, descript, active'),
    (446, 'Importer cat_feature_connec', E'Le fichier CSV doit contenir les colonnes suivantes dans exactement le même ordre : \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (448, 'Importer cat_node', E'Le fichier CSV doit contenir les colonnes suivantes dans exactement le même ordre : \nid, nodetype_id, matcat_id, pnom, dnom, dint, dext, shape, descript, link, brand, model, svg, estimated_depth, cost_unit, cost, active, label, ischange, acoeff'),
    (449, 'Importer cat_connec', E'Le fichier CSV doit contenir les colonnes suivantes dans exactement le même ordre : \nid, connectype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, active, label'),
    (450, 'Importer cat_arc', 'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : id, arctype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, z1, z2, width, area, estimated_depth, bulk, cost_unit, cost, m2bottom_cost, m3protec_cost, active, label, shape, acoeff, connect_cost'),
    (469, 'Importer les valeurs SCADA', 'Importer les valeurs SCADA dans la table ext_rtc_scada_x_data selon le fichier d''exemple scada_values.csv'),
    (470, 'Importer hydrometer_x_data', 'Le fichier CSV doit avoir les champs suivants : hydrometer_id, cat_period_id, sum, value_date (optional), value_type (optional), value_status (optional), value_state (optional)'),
    (471, 'Importer les valeurs de période CRM', 'Le fichier CSV doit avoir les champs suivants : id, start_date, end_date, period_seconds (optional), code'),
    (500, 'Importer l''état des vannes', 'Le fichier CSV doit contenir les champs suivants : dscenario_name, node_id, status'),
    (501, 'Importer les demandes dscenario', 'Le fichier csv doit contenir les champs suivants : dscenario_name, feature_id, feature_type, value, demand_type, pattern_id, source'),
    (504, 'Importer les valeurs journalières du débitmètre', 'Importer les valeurs journalières du débitmètre dans la table ext_rtc_scada_x_data selon le fichier exemple scada_flowmeter_daily_values.csv'),
    (506, 'Importer les valeurs agrégées du débitmètre', 'Importer les valeurs agrégées du débitmètre dans la table ext_rtc_scada_x_data selon le fichier exemple scada_flowmeter_agg_values.csv'),
    (514, 'Importer les vannes fermées du netscenario', 'Le fichier csv doit contenir les champs suivants : netscenario_id, node_id, closed')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;