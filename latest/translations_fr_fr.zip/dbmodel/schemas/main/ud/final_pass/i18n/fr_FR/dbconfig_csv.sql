/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'Importer les prix en base de données', E'Le fichier CSV doit contenir les colonnes suivantes, aux mêmes positions : id, unit, descript, text, price. \n- La colonne price doit être numérique avec deux décimales. \n- Vous pouvez choisir un nom de catalogue pour ces prix en définissant un libellé d''import.'),
    (235, 'Importer des éléments', E'Le fichier CSV doit contenir les colonnes suivantes aux mêmes positions :\nId (arc_id, node_id, connec_id), code, elementcat_id, observ, comment, num_elements, state type (id), workcat_id, verified (choisir dans edit_typevalue>value_verified).\n- Les champs Observations et Comments sont optionnels\n- ATTENTION ! Le champ d''import ''label'' doit être rempli avec le type d''élément (node, arc, connec)'),
    (238, 'Importation om visit', E'Pour utiliser ce paramètre de fonction d''import csv, vous devez configurer avant son exécution le paramètre système ''utils_csv2pg_om_visit_parameters''.\nNous recommandons également de lire auparavant les annotations à l''intérieur de la fonction afin de fonctionner aussi bien que possible avec celle-ci'),
    (384, 'Importation de fichiers inp de courbes', E'Fonction pour automatiser l''importation de fichiers inp contenant des courbes.\nLe fichier csv doit contenir les colonnes suivantes aux mêmes positions :\ncurve_id, x_value, y_value, curve_type (pour les projets WS ou UD, curve_type a des valeurs différentes. Consultez le manuel utilisateur)'),
    (385, 'Importer séries temporelles inp', 'Fonction d''aide à l''import des séries temporelles pour les modèles inp. Le fichier csv doit contenir les colonnes suivantes aux mêmes positions : timseries, timser_type, times_type, descript, expl_id, date, hour, time, value (remplir date/hour pour ABSOLUTE ou time pour RELATIVE)'),
    (386, 'Importation de fichiers inp de patterns', E'Fonction pour automatiser l''importation de fichiers inp contenant des patterns.\nLe fichier csv doit contenir les colonnes suivantes aux mêmes positions :\npattern_id, pattern_type, factor1,.......,factorn.\nPour WS, utilisez jusqu''à factor18, en répétant les lignes si vous le souhaitez.\nPour UD, utilisez jusqu''à factor24. Plus d''une ligne par pattern n''est pas autorisée'),
    (408, 'Importer les nœuds istram', NULL),
    (409, 'Importer les arcs istram', NULL),
    (444, 'Importer cat_feature_arc', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (445, 'Importer cat_feature_node', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, system_id, epa_default, isarcdivide, isprofilesurface, choose_hemisphere, code_autofill, double_geom, num_arcs, graph_delimiter, shortcut_key, link_path, descript, active'),
    (446, 'Importer cat_feature_connec', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (447, 'Importer cat_feature_gully', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, system_id, epa_default, code_autofill, double_geom, shortcut_key, link_path, descript, active'),
    (448, 'Importer cat_node', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, nodetype_id, matcat_id, pnom, dnom, dint, dext, shape, descript, link, brand, model, svg, estimated_depth, cost_unit, cost, active, label, ischange, acoeff'),
    (449, 'Importer cat_connec', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, connectype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, active, label'),
    (450, 'Importer cat_arc', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, arctype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, z1, z2, width, area, estimated_depth, bulk, cost_unit, cost, m2bottom_cost, m3protec_cost, active, label, shape, acoeff, connect_cost'),
    (451, 'Importer cat_grate', E'Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact : \nid, matcat_id, length, width, total_area, effective_area, n_barr_l, n_barr_w, n_barr_diag, a_param, b_param, descript, link, brand, model, svg, active, label, gully_type'),
    (469, 'Importer valeurs SCADA', 'Importer les valeurs SCADA dans la table ext_rtc_scada_x_data selon le fichier exemple scada_values.csv'),
    (470, 'Importer hydrometer_x_data', E'Le fichier CSV doit contenir les champs suivants :\nhydrometer_id, cat_period_id, sum, value_date (optional), value_type (optional), value_status (optional), value_state (optional)'),
    (471, 'Importer valeurs de période CRM', E'Le fichier CSV doit contenir les champs suivants :\nid, start_date, end_date, period_seconds (optional), code'),
    (527, 'Importer DWF', 'Fonction d''importation des valeurs DWF. Le fichier CSV doit contenir les colonnes suivantes dans le même ordre exact :   dwfscenario_id, node_id, value, pat1, pat2, pat3, pat4')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;