/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'Importar preços da bd', E'O ficheiro csv deve conter as seguintes colunas na mesma posição: id, unit, descript, text, price. \n- A coluna price deve ser numérica com duas casas decimais. \n- Pode escolher um nome de catálogo para estes preços definindo um rótulo de importação.'),
    (235, 'Importar elementos', E'O ficheiro csv deve conter as seguintes colunas na mesma posição:\nId (arc_id, node_id, connec_id), code, elementcat_id, observ, comment, num_elements, state type (id), workcat_id, verified (choose from edit_typevalue>value_verified).\n- Os campos Observations e comments são opcionais\n- ATENÇÃO! O rótulo de importação tem de ser preenchido com o tipo de elemento (node, arc, connec)'),
    (238, 'Importar om visit', E'Para usar esta função de importação csv de parâmetros om visit necessita de configurar previamente o parâmetro do sistema ''utils_csv2pg_om_visit_parameters''. \nTambém recomendamos ler previamente as anotações dentro da função para trabalhar tão bem quanto possível com ela'),
    (384, 'Importar curvas inp', E'Função para automatizar a importação de ficheiros de curvas inp. \nO ficheiro csv deve conter as seguintes colunas na mesma posição: \ncurve_id, x_value, y_value, curve_type (para projeto WS OU projeto UD curve_type tem valores diferentes. Ver manual do utilizador)'),
    (386, 'Importar padrões inp', E'Função para automatizar a importação de ficheiros de padrões inp. \nO ficheiro csv deve conter as seguintes colunas na mesma posição: \npattern_id, pattern_type, factor1,.......,factorn. \nPara WS use até factor18, repetindo linhas se desejar. \nPara UD use até factor24. Não é permitida mais do que uma linha por pattern'),
    (444, 'Importar cat_feature_arc', E'O ficheiro csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (445, 'Importar cat_feature_node', E'O ficheiro csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, isarcdivide, isprofilesurface, choose_hemisphere, code_autofill, double_geom, num_arcs, graph_delimiter, shortcut_key, link_path, descript, active'),
    (446, 'Importar cat_feature_connec', E'O ficheiro csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (448, 'Importar cat_node', E'O ficheiro csv deve conter as seguintes colunas na mesma ordem exata: \nid, nodetype_id, matcat_id, pnom, dnom, dint, dext, shape, descript, link, brand, model, svg, estimated_depth, cost_unit, cost, active, label, ischange, acoeff'),
    (449, 'Importar cat_connec', E'O ficheiro csv deve conter as seguintes colunas na mesma ordem exata: \nid, connectype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, active, label'),
    (450, 'Importar cat_arc', E'O ficheiro csv deve conter as seguintes colunas na mesma ordem exata: \nid, arctype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, z1, z2, width, area, estimated_depth, bulk, cost_unit, cost, m2bottom_cost, m3protec_cost, active, label, shape, acoeff, connect_cost'),
    (469, 'Importar valores scada', 'Importar valores scada para a tabela ext_rtc_scada_x_data conforme o ficheiro de exemplo scada_values.csv'),
    (470, 'Importar hydrometer_x_data', E'O ficheiro csv deve ter os seguintes campos:\nhydrometer_id, cat_period_id, sum, value_date (opcional), value_type (opcional), value_status (opcional), value_state (opcional)'),
    (471, 'Importar valores de período crm', E'O ficheiro csv deve ter os seguintes campos:\nid, start_date, end_date, period_seconds (opcional), code'),
    (500, 'Importar estado de válvulas', E'O ficheiro csv deve ter os seguintes campos:\ndscenario_name, node_id, status'),
    (501, 'Importar pedidos dscenario', E'O ficheiro csv deve ter os seguintes campos:\ndscenario_name, feature_id, feature_type, value, demand_type, pattern_id, source'),
    (504, 'Importar valores diários do caudalímetro', 'Importar valores diários de medidor de caudal para a tabela ext_rtc_scada_x_data conforme o ficheiro de exemplo scada_flowmeter_daily_values.csv'),
    (506, 'Importar valores agregados de medidor de caudal', 'Importar valores agregados de medidor de caudal para a tabela ext_rtc_scada_x_data conforme o ficheiro de exemplo scada_flowmeter_agg_values.csv'),
    (514, 'Importar válvulas fechadas em netscenario', E'O ficheiro csv deve ter os seguintes campos:\nnetscenario_id, node_id, closed')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;