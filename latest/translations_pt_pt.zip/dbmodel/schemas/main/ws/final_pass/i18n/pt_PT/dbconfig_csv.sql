/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'a', 'a'),
    (235, 'a', 'a'),
    (238, 'a', 'a'),
    (384, 'a', 'a'),
    (386, 'a', 'a'),
    (444, 'a', 'a'),
    (445, 'a', 'a'),
    (446, 'a', 'a'),
    (448, 'a', 'a'),
    (449, 'a', 'a'),
    (450, 'a', 'a'),
    (469, 'a', 'a'),
    (470, 'a', 'a'),
    (471, 'a', 'a'),
    (500, 'a', 'a'),
    (501, 'a', 'a'),
    (504, 'a', 'a'),
    (506, 'a', 'a'),
    (514, 'a', 'a')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;