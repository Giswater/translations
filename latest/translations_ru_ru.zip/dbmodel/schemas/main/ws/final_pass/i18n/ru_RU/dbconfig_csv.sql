/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'Импорт db цен', E'CSV-файл должен содержать следующие столбцы в указанном порядке: id, unit, descript, text, price.\n- Столбец price должен быть числовым с двумя десятичными знаками.\n- Можно задать имя каталога для этих цен, указав метку импорта.'),
    (235, 'Импорт элементов', E'CSV-файл должен содержать следующие столбцы в указанном порядке:\nId (arc_id, node_id, connec_id), code, elementcat_id, observ, comment, num_elements, state type (id), workcat_id, verified (выбрать из edit_typevalue>value_verified).\n- Поля observ и comment являются необязательными.\n- ВНИМАНИЕ! Поле Import label должно быть заполнено типом элемента (node, arc, connec)'),
    (238, 'Импорт om visit', E'Для использования этой функции импорта CSV необходимо предварительно настроить системный параметр ''utils_csv2pg_om_visit_parameters''.\nТакже рекомендуется перед выполнением прочитать аннотации внутри функции, чтобы работать как можно корректнее с ней.'),
    (384, 'Импорт inp кривых', E'Функция для автоматизации импорта файлов INP-кривых.\nCSV-файл должен содержать следующие столбцы в указанном порядке:\ncurve_id, x_value, y_value, curve_type (для проекта WS ИЛИ проекта UD значение curve_type отличается. Смотрите руководство пользователя)'),
    (386, 'Импорт inp шаблонов', E'Функция для автоматизации импорта файлов INP-шаблонов.\nCSV-файл должен содержать следующие столбцы в указанном порядке:\npattern_id, pattern_type, factor1,.......,factorn.\nДля WS используйте до factor18, при необходимости повторяя строки.\nДля UD используйте до factor24. Более одной строки для одного pattern не допускается'),
    (444, 'Импорт cat_feature_arc', E'CSV-файл должен содержать следующие столбцы в точно таком же порядке: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (445, 'Импорт cat_feature_node', E'CSV-файл должен содержать следующие столбцы в точно таком же порядке: \nid, system_id, epa_default, isarcdivide, isprofilesurface, choose_hemisphere, code_autofill, double_geom, num_arcs, graph_delimiter, shortcut_key, link_path, descript, active'),
    (446, 'Импорт cat_feature_connec', E'CSV-файл должен содержать следующие столбцы в точно таком же порядке: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (448, 'Импорт cat_node', E'CSV-файл должен содержать следующие столбцы в точно таком же порядке: \nid, nodetype_id, matcat_id, pnom, dnom, dint, dext, shape, descript, link, brand, model, svg, estimated_depth, cost_unit, cost, active, label, ischange, acoeff'),
    (449, 'Импорт cat_connec', E'CSV-файл должен содержать следующие столбцы в точно таком же порядке: \nid, connectype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, active, label'),
    (450, 'Импорт cat_arc', E'CSV-файл должен содержать следующие столбцы в точно таком же порядке: \nid, arctype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, z1, z2, width, area, estimated_depth, bulk, cost_unit, cost, m2bottom_cost, m3protec_cost, active, label, shape, acoeff, connect_cost'),
    (469, 'Импорт значений scada', 'Импортировать значения SCADA в таблицу ext_rtc_scada_x_data согласно примеру файла scada_values.csv'),
    (470, 'Импорт hydrometer_x_data', E'CSV-файл должен иметь следующие поля:\nhydrometer_id, cat_period_id, sum, value_date (необязательно), value_type (необязательно), value_status (необязательно), value_state (необязательно)'),
    (471, 'Импорт значений crm period', E'CSV-файл должен иметь следующие поля:\nid, start_date, end_date, period_seconds (необязательно), code'),
    (500, 'Импорт статуса клапана', E'CSV-файл должен иметь следующие поля:\ndscenario_name, node_id, status'),
    (501, 'Импорт dscenario demands', E'CSV-файл должен содержать следующие поля:\ndscenario_name, feature_id, feature_type, value, demand_type, pattern_id, source'),
    (504, 'Импорт суточных значений расходомера', 'Импорт суточных значений расходомера в таблицу ext_rtc_scada_x_data согласно примеру файла scada_flowmeter_daily_values.csv'),
    (506, 'Импорт агрегированных значений расходомера', 'Импорт агрегированных значений расходомеров в таблицу ext_rtc_scada_x_data согласно примеру файла scada_flowmeter_agg_values.csv'),
    (514, 'Импорт закрытых клапанов в netscenario', E'CSV-файл должен содержать следующие поля:\nnetscenario_id, node_id, closed')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;